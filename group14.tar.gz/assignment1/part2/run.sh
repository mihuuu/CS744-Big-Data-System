#!/bin/sh

docker exec master python3 task.py