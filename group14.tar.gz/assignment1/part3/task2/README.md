## Task2
In this task, we can experiment with different partitions

The .sh file will run with partition 10, 50, 100, 200, 300 iteratively

You can change the partition options in the loop as you like.