#!/bin/sh

docker exec master python3 /src/task3.py /task1/ task3-out