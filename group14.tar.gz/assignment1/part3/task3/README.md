## Task3
In this task, we use a fixed partition number of 100 and the dataframe of edges is cached

You can run .sh file without parameters