#!/bin/sh

docker exec master python3 /src/task4.py /task1/ task4-25-out task4-25
# docker exec master python3 /src/task4.py /task1/ task4-75-out task4-75