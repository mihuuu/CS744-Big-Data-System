## Task3
In this task, we use a fixed partition number of 100 and the dataframe of edges is cached (same as Task3)

You can run .sh file without parameters.

You need to manually kill a worker process when the application reaches 25% and 75% of its lifetime.
