#!/bin/sh

#dataset: web-BerkStan
# docker exec master python3 /src/task1.py /web-BerkStan.txt web-out.txt

# dataset: enwiki
docker exec master python3 /src/task1.py /task1/ task1-out
