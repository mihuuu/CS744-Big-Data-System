## Task1
This task runs the PageRank algorithm with default settings.

Run file-upload.sh to upload the input dataset to HDFS
You can run task1.sh file on web-BerkStan.txt or enwiki-pages-articles (should be uploaded to HDFS first)
